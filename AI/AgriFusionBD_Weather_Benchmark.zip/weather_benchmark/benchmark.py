# %% Setup
from pathlib import Path
import json, hashlib, platform, warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, brier_score_loss, average_precision_score
from catboost import CatBoostRegressor, CatBoostClassifier
import sklearn, catboost
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore', category=FutureWarning)
ROOT = Path.cwd()
DATA = ROOT / 'data'
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
SEED = 42
# Retrospective data-date experiment: day t observations are assumed known.
# Actual historical delivery timestamps are unavailable. NOT operational forecast accuracy.

# %% Load and audit: one copy per source; never use flagged POWER rainfall
files = sorted(DATA.glob('*_20220101_to_20261025.csv'))
assert len(files) == 7
power = pd.concat([pd.read_csv(p) for p in files], ignore_index=True)
gpm = pd.read_csv(next(DATA.glob('GPM_IMERG_all*')))
power = power.replace([-999, -9999], np.nan).drop(columns=['PRECTOTCORR'])
gpm = gpm.replace([-999, -9999], np.nan)
for frame in [power, gpm]:
    frame['date'] = pd.to_datetime(frame['date'])
    assert not frame.duplicated(['region', 'date']).any()
panel = gpm[['region','date','precipitation_mm_day','run']].merge(power, on=['region','date'], how='left', validate='one_to_one')
panel = panel.sort_values(['region','date']).reset_index(drop=True)
assert panel.groupby('region').date.diff().dropna().eq(pd.Timedelta(days=1)).all()
assert panel.precipitation_mm_day.dropna().ge(0).all()
assert 'PRECTOTCORR' not in panel
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob('*.csv')}
(OUT/'input_hashes.json').write_text(json.dumps(manifest, indent=2))
print('Rows:', len(panel), 'Regions:', panel.region.nunique())
print(panel.groupby('region').agg(start=('date','min'),end=('date','max')))

# %% Feature engineering: only observation date t and earlier
raw = ['T2M','T2M_MAX','T2M_MIN','RH2M','WS2M','PS','precipitation_mm_day']
# Solar is excluded for all periods because the 2026 tail is missing for months.
features = pd.DataFrame(index=panel.index)
doy = panel.date.dt.dayofyear
features['doy_sin'] = np.sin(2*np.pi*doy/365.25)
features['doy_cos'] = np.cos(2*np.pi*doy/365.25)
for region in sorted(panel.region.unique()):
    features['region_'+region] = (panel.region == region).astype(float)
for col in raw:
    group = panel.groupby('region')[col]
    for lag in [0,1,2,3,7,14]:
        features[f'{col}_lag{lag}'] = group.shift(lag)
    for window in [3,7,14,30]:
        features[f'{col}_mean{window}'] = group.transform(lambda s: s.rolling(window,min_periods=window).mean())
        features[f'{col}_std{window}'] = group.transform(lambda s: s.rolling(window,min_periods=window).std())
features['diurnal_range'] = panel.T2M_MAX-panel.T2M_MIN
for window in [7,14,30]:
    features[f'rain_sum{window}'] = panel.groupby('region').precipitation_mm_day.transform(lambda s:s.rolling(window,min_periods=window).sum())
    features[f'wet_fraction{window}'] = panel.groupby('region').precipitation_mm_day.transform(lambda s:s.ge(1).where(s.notna()).rolling(window,min_periods=window).mean())
for col in list(features):
    if features[col].isna().any(): features[col+'_missing'] = features[col].isna().astype(float)
# Conservative common experimental window: complete weather at issue date and 30 days history.
eligible = panel[raw].notna().all(axis=1) & panel.groupby('region').cumcount().ge(29)
assert features.index.equals(panel.index)
assert not any('target' in c or 'PRECTOTCORR' in c for c in features)
(OUT/'feature_schema.json').write_text(json.dumps(list(features),indent=2))
print('Feature count:',len(features.columns))

# %% Metrics and model definitions
CONFIGS = {'compact':dict(depth=4, leaves=15, l2=5), 'flexible':dict(depth=6, leaves=31, l2=10)}
def make_model(family, config, classifier=False):
    c=CONFIGS[config]
    if family=='CatBoost':
        cls=CatBoostClassifier if classifier else CatBoostRegressor
        return cls(iterations=200, depth=c['depth'], learning_rate=.05, l2_leaf_reg=c['l2'],
                   loss_function='Logloss' if classifier else 'RMSE', random_seed=SEED,
                   thread_count=2, verbose=False, allow_writing_files=False)
    cls=HistGradientBoostingClassifier if classifier else HistGradientBoostingRegressor
    return cls(max_iter=200,max_leaf_nodes=c['leaves'],learning_rate=.05,
               l2_regularization=c['l2'], min_samples_leaf=30, early_stopping=False,random_state=SEED)

def scores(y,p,prob=None):
    result={'n':len(y),'MAE':mean_absolute_error(y,p),'RMSE':np.sqrt(mean_squared_error(y,p)), 'bias':float(np.mean(p-y))}
    if prob is not None:
        wet=np.asarray(y)>=1
        result.update(Brier=brier_score_loss(wet,prob),AP=average_precision_score(wet,prob) if wet.any() else np.nan,
                      wet_MAE=mean_absolute_error(np.asarray(y)[wet],np.asarray(p)[wet]) if wet.any() else np.nan,
                      heavy20_MAE=mean_absolute_error(np.asarray(y)[np.asarray(y)>=20],np.asarray(p)[np.asarray(y)>=20]) if (np.asarray(y)>=20).any() else np.nan)
    return result

def fit_predict(family,config,train,evaluate,y,rain):
    if not rain:
        model=make_model(family,config).fit(features.loc[train],y.loc[train])
        return model.predict(features.loc[evaluate]),None
    # Hurdle model: wet day >=1 mm; amounts below 1 represented by train-only dry mean.
    wet=y.loc[train]>=1
    classifier=make_model(family,config,True).fit(features.loc[train],wet.astype(int))
    amount=make_model(family,config).fit(features.loc[train[wet.to_numpy()]],y.loc[train[wet.to_numpy()]])
    prob=classifier.predict_proba(features.loc[evaluate])[:,1]
    conditional=np.maximum(1,amount.predict(features.loc[evaluate]))
    dry_mean=float(y.loc[train][~wet].mean())
    return prob*conditional+(1-prob)*dry_mean,prob

def baselines(train,evaluate,y,target_date,rain,col):
    # Monthly regional statistics use only training targets, including target's month.
    tr=pd.DataFrame({'region':panel.loc[train,'region'],'month':target_date.loc[train].dt.month,'y':y.loc[train]})
    climatology=tr.groupby(['region','month']).y.mean()
    keys=pd.MultiIndex.from_arrays([panel.loc[evaluate,'region'],target_date.loc[evaluate].dt.month])
    seasonal=climatology.reindex(keys).to_numpy()
    assert np.isfinite(seasonal).all()
    persistent=panel.loc[evaluate,col].to_numpy()
    if rain:
        wet_clim=tr.assign(wet=tr.y.ge(1)).groupby(['region','month']).wet.mean().reindex(keys).to_numpy()
        return {'Persistence':(persistent,(persistent>=1).astype(float)),'SeasonalMean':(seasonal,wet_clim)}
    return {'Persistence':(persistent,None),'SeasonalMean':(seasonal,None)}

# %% Validation (2025), frozen selection, then final 2026 test
# Training: 2022-2024. Both issue AND target must precede split boundaries.
# Refit selected configurations on 2022-2025; 2026 never selects parameters.
metrics=[]; predictions=[]; selections=[]
for col,task in [('T2M','mean_temperature'),('T2M_MAX','maximum_temperature'),('precipitation_mm_day','rainfall')]:
    for horizon in [1,3]:
        print('Running',task,'T+',horizon,flush=True)
        rain=task=='rainfall'
        y=panel.groupby('region')[col].shift(-horizon)
        target_date=panel.date+pd.to_timedelta(horizon,unit='D')
        valid=eligible & y.notna()
        train=panel.index[valid & target_date.lt('2025-01-01')]
        val=panel.index[valid & panel.date.ge('2025-01-01') & target_date.lt('2026-01-01')]
        full=panel.index[valid & target_date.lt('2026-01-01')]
        test=panel.index[valid & panel.date.ge('2026-01-01')]
        assert target_date.loc[train].max()<panel.loc[val,'date'].min()
        assert target_date.loc[full].max()<panel.loc[test,'date'].min()
        test_models=baselines(full,test,y,target_date,rain,col)
        for name,(p,prob) in baselines(train,val,y,target_date,rain,col).items():
            metrics.append(dict(task=task,horizon=horizon,split='validation',model=name,config='baseline',**scores(y.loc[val],p,prob)))
        for family in ['CatBoost','HistGradientBoosting']:
            candidates=[]
            for config in CONFIGS:
                p,prob=fit_predict(family,config,train,val,y,rain)
                score=scores(y.loc[val],p,prob)
                metrics.append(dict(task=task,horizon=horizon,split='validation',model=family,config=config,**score))
                candidates.append((score['Brier'] if rain else score['MAE'],config))
            best=min(candidates)[1]
            selections.append(dict(task=task,horizon=horizon,model=family,selected_config=best,criterion='Brier' if rain else 'MAE'))
            test_models[family]=fit_predict(family,best,full,test,y,rain)
        for name,(p,prob) in test_models.items():
            metrics.append(dict(task=task,horizon=horizon,split='test',model=name,config='validation_selected' if name not in ['Persistence','SeasonalMean'] else 'baseline',**scores(y.loc[test],p,prob)))
            record=panel.loc[test,['region','date','run']].copy().rename(columns={'date':'issue_date','run':'issue_gpm_stream'})
            record['target_date']=target_date.loc[test]
            record['target_gpm_stream']=panel.groupby('region').run.shift(-horizon).loc[test]
            record['task']=task;record['horizon']=horizon;record['model']=name
            record['actual']=y.loc[test];record['prediction']=p
            record['wet_probability']=np.nan if prob is None else prob
            predictions.append(record)
        pd.DataFrame(metrics).to_csv(OUT/'metrics.csv',index=False)
        pd.DataFrame(selections).to_csv(OUT/'selected_configurations.csv',index=False)
results=pd.DataFrame(metrics)
pred=pd.concat(predictions,ignore_index=True)
pred.to_csv(OUT/'test_predictions.csv',index=False)
print(results[results.split=='test'].to_string(index=False))

# %% Diagnostics by region and calendar month; paired date-block bootstrap
rows=[]
for grouping in ['region','month']:
    pred['month']=pd.to_datetime(pred.target_date).dt.month
    for keys,g in pred.groupby(['task','horizon','model',grouping]):
        task,horizon,model,label=keys
        rows.append(dict(task=task,horizon=horizon,model=model,grouping=grouping,label=label,**scores(g.actual,g.prediction,g.wet_probability if task=='rainfall' else None)))
pd.DataFrame(rows).to_csv(OUT/'subgroup_metrics.csv',index=False)
# Bootstrap paired daily mean losses, shared across regions, 14-day moving blocks.
# Conditional on fitted models; descriptive uncertainty, no refitting or multiplicity correction.
rng=np.random.default_rng(SEED);intervals=[]
for (task,horizon),g in pred.groupby(['task','horizon']):
    criterion='Brier' if task=='rainfall' else 'MAE'
    g=g.copy()
    g['loss']=(g.wet_probability-(g.actual>=1))**2 if task=='rainfall' else abs(g.prediction-g.actual)
    daily=g.groupby(['issue_date','model']).loss.mean().unstack()
    for model in ['CatBoost','HistGradientBoosting']:
        for baseline in ['Persistence','SeasonalMean']:
            diff=(daily[model]-daily[baseline]).dropna().to_numpy(); n=len(diff)
            boot=[]
            for _ in range(1000):
                starts=rng.integers(0,n-14+1,size=int(np.ceil(n/14)))
                idx=np.concatenate([np.arange(s,s+14) for s in starts])[:n]
                boot.append(diff[idx].mean())
            intervals.append(dict(task=task,horizon=horizon,model=model,baseline=baseline,metric=criterion,loss_difference=diff.mean(),lower95=np.quantile(boot,.025),upper95=np.quantile(boot,.975)))
pd.DataFrame(intervals).to_csv(OUT/'paired_block_intervals.csv',index=False)
# Reliability bins: no probability recalibration on test.
cal=[]
for (h,m),g in pred[pred.task=='rainfall'].groupby(['horizon','model']):
    b=np.minimum((g.wet_probability*10).astype(int),9)
    for binid,s in g.groupby(b):
        cal.append(dict(horizon=h,model=m,bin=int(binid),n=len(s),mean_probability=s.wet_probability.mean(),observed_wet_fraction=s.actual.ge(1).mean()))
pd.DataFrame(cal).to_csv(OUT/'rain_calibration.csv',index=False)
fig,axes=plt.subplots(2,3,figsize=(15,8))
for j,task in enumerate(['mean_temperature','maximum_temperature','rainfall']):
    for i,h in enumerate([1,3]):
        sub=results[(results.split=='test') & (results.task==task) & (results.horizon==h)]
        metric='Brier' if task=='rainfall' else 'MAE'
        axes[i,j].bar(sub.model,sub[metric],color=['#999999','#59788e','#238b45','#5c56a3'])
        axes[i,j].set_title(f'{task} | T+{h} | {metric}')
        axes[i,j].tick_params(axis='x',labelrotation=30)
        axes[i,j].set_ylabel('Brier score' if task=='rainfall' else '°C')
fig.tight_layout();fig.savefig(OUT/'benchmark_comparison.png',dpi=160);plt.show()
(OUT/'environment.json').write_text(json.dumps({'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,'sklearn':sklearn.__version__,'catboost':catboost.__version__,'seed':SEED},indent=2))
print('Completed. Results are retrospective; no operational deployment claim.')
