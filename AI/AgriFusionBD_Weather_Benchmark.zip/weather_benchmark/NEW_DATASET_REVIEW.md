# Review of new engineered datasets

Inspected all seven new attachments: daily_panel.csv (12,313 x 66), monthly_panel.csv (406 x 37), feature dictionary, quality report, split manifest, README and baseline results. Builder and training scripts are referenced but were not provided, so their full implementation was not verified.

## Verified strengths

No duplicate region/date keys. All four daily targets exactly equal a within-region next-day shift of their corresponding series. Corrected POWER rainfall equals the original divided by 24, including missingness. The README reports 40 live checks; those additional API responses were not supplied or independently repeated here. Sparse observations have age and observation-day fields, and the manifest uses chronological years.

## Fix before stronger claims

1. SMAP flags contain 7.5 and 10.5. These are bit fields, not quantities that can be averaged. Even integer 8 may be an aggregate of other codes, so it cannot certify quality. Screen original AM/PM retrievals individually before averaging accepted moisture values. Current soil labels do not demonstrate recommended-quality-only screening.
2. All 21 rows missing Tmax have heat_day_35=0. Missing is unknown, not a non-heat event. The shifted heat target inherits these false zeros; actual non-null heat targets number 12,306 while the README claims 12,285.
3. Rolling sums can contain partial windows: on 25 October 2026, a 7-day ET0 sum exists despite missing daily ET0 for 23–25 October. Add valid-day counts and require full windows for claimed totals; otherwise clearly label partial sums. Dry spells must not count missing rainfall as dry.
4. GRACE values enter the daily panel at their nominal monthly midpoint, e.g. 16 January. These are not delivery dates. The README's no-future-information claim is insufficient for operational forecasting. HLS/ECOSTRESS also need acquisition-versus-release timestamps. Monthly tables labelled at month start contain whole-month information, so use month-end feature availability.
5. The split manifest uses issue dates. Seven 31 December 2024 rows have targets on 1 January 2025, and seven 31 December 2025 rows have targets in 2026. Purge them for strict year-separated evaluation. Monthly forward targets need analogous target-date boundaries. Confirm actual training behavior in the missing script.
6. Persistence moisture metrics use 734 test rows while models use 1,400; NDVI persistence uses 15 while models use 26. Compare each model on exactly the same target rows and report full-coverage scores separately.
7. Monthly index is a sequential identifier, encoding both region and time; it is the leading reported NDVI importance. Drop it and use explicit region/calendar features. Importance alone is not proof of target leakage, but this is a spurious proxy risk.
8. October 2026 only covers 1–25 October but appears as a monthly total. Exclude incomplete-month targets or add completeness flags. September rows that target October inherit partial-total labels.
9. Of 218 aligned valid HLS acquisitions, 153 have less than 70% clear coverage. That threshold is a proposed sensitivity screen, not a universal NASA rule. Daily features lack the original clear-coverage value. Keep quality/provenance with carried values; observation age does not establish quality. The known extraction-window mismatch also remains unresolved.
10. ET0 is calculated, not measured irrigation or crop water use. Verify both equations from the source code and evaluate Penman–Monteith and Hargreaves periods separately. The monthly et0_mm is missing for the late period despite daily fallback ET0, so monthly and daily aggregation policies need reconciliation.

## Supplied results

Rainfall MAE: persistence 5.7004, ridge 6.8609, gradient boosting 7.6336 mm/day. Ridge improves RMSE (11.3109 versus persistence 12.56), demonstrating a metric tradeoff, not overall dominance. Gradient boosting's reported R2 is -0.1951.

Soil gradient boosting R2=0.6741 is promising for reproducing the supplied satellite series but cannot yet establish field soil accuracy, due to quality flags and unequal baseline coverage.

ET0 ridge MAE=0.4462 versus persistence=0.4675 mm/day: a modest ~4.6% improvement for predicting a computed reference quantity.

NDVI ridge R2=0.5655 is based on only 26 test targets, with an index feature and unequal baseline coverage. Treat it as exploratory.

## Practical uses

First: regional monitoring dashboards, temperature/heat experiments, rainfall occurrence models and evaporation-demand experiments after the fixes. Monthly data can summarize historical seasonal conditions and support scenario comparisons. Next: quality-controlled surface moisture and vegetation monitoring. Crop rotation should remain a reviewed rule/scenario engine requiring field soil tests, crop calendar/history, water access and farmer priorities. These panels cannot train validated NPK, pH, crop-yield, disease or best-next-crop models without measured labels.
