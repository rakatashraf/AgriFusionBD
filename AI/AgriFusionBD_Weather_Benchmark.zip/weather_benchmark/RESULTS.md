# Measured weather benchmark results

Retrospective scores from executed code. Lower MAE and Brier are better.

| Task | Horizon | Model | MAE | RMSE | Brier |
|---|---|---|---:|---:|---:|
| mean_temperature | 1 days | Persistence | 0.5591 | 0.7587 | — |
| mean_temperature | 1 days | SeasonalMean | 1.0995 | 1.5100 | — |
| mean_temperature | 1 days | CatBoost | 0.5374 | 0.7290 | — |
| mean_temperature | 1 days | HistGradientBoosting | 0.5155 | 0.7051 | — |
| mean_temperature | 3 days | Persistence | 0.9112 | 1.2164 | — |
| mean_temperature | 3 days | SeasonalMean | 1.0961 | 1.5083 | — |
| mean_temperature | 3 days | CatBoost | 0.7766 | 1.0638 | — |
| mean_temperature | 3 days | HistGradientBoosting | 0.7969 | 1.0939 | — |
| maximum_temperature | 1 days | Persistence | 0.8526 | 1.1714 | — |
| maximum_temperature | 1 days | SeasonalMean | 1.4914 | 2.0237 | — |
| maximum_temperature | 1 days | CatBoost | 0.7832 | 1.0569 | — |
| maximum_temperature | 1 days | HistGradientBoosting | 0.7617 | 1.0385 | — |
| maximum_temperature | 3 days | Persistence | 1.2663 | 1.7171 | — |
| maximum_temperature | 3 days | SeasonalMean | 1.4859 | 2.0207 | — |
| maximum_temperature | 3 days | CatBoost | 1.0765 | 1.4717 | — |
| maximum_temperature | 3 days | HistGradientBoosting | 1.0873 | 1.4859 | — |
| rainfall | 1 days | Persistence | 5.7366 | 12.6024 | 0.2334 |
| rainfall | 1 days | SeasonalMean | 7.0616 | 11.9642 | 0.1648 |
| rainfall | 1 days | CatBoost | 5.6883 | 10.5041 | 0.1437 |
| rainfall | 1 days | HistGradientBoosting | 5.9527 | 10.8294 | 0.1445 |
| rainfall | 3 days | Persistence | 6.7062 | 14.7640 | 0.2915 |
| rainfall | 3 days | SeasonalMean | 7.1044 | 11.9761 | 0.1660 |
| rainfall | 3 days | CatBoost | 6.7722 | 11.7761 | 0.1609 |
| rainfall | 3 days | HistGradientBoosting | 7.2741 | 12.6738 | 0.1646 |

Temperature errors are °C; rainfall errors mm/day.

HistGradientBoosting has the lowest one-day mean and maximum-temperature MAE. CatBoost has the lowest three-day temperature MAE. CatBoost has the lowest one-day rain-amount MAE and lowest rain Brier at both horizons. Three-day rainfall amount MAE remains worse than persistence. These are descriptive held-out comparisons, not deployment selections.

The one-day mean-temperature MAE improvement for HistGradientBoosting over persistence is 7.8%; three-day CatBoost improvement is 14.8%. Block bootstrap intervals favor these models over persistence. CatBoost one-day mean-temperature improvement has an interval spanning zero. See paired_block_intervals.csv.

Results do not represent operational forecast skill. Observation delivery latency is unavailable; GPM changes from Final to Late Run before the test period. No gauge validation or outer rolling-fold evaluation was performed.

Notebook cells were executed sequentially in one Python namespace and outputs captured because this host did not permit Jupyter socket transport. It is a standard v4 notebook for VS Code.