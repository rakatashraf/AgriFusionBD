# AgriFusionBD weather benchmark

Open this folder in VS Code. Use Python 3.12, install the Python and Jupyter extensions, then run:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Open `AgriFusionBD_Weather_Benchmark.ipynb`, select `.venv` as the kernel and Run All. The notebook already contains outputs from a completed execution. Alternatively run `python benchmark.py` from this folder. Training takes several minutes. No NASA credentials or downloads are required: input CSV copies are included.

## Scope

The benchmark was started on the original NASA CSVs, before the new engineered daily/monthly panels were uploaded. It intentionally excludes erroneous POWER rainfall and uses GPM rainfall instead. It does not reuse the supplied baseline_results.json. The two result sets have different feature sets and test coverage and must not be compared as a controlled experiment.

Train 2022–2024; select two fixed configurations per algorithm on 2025; refit on 2022–2025 and evaluate 2026. All locations share date boundaries; targets crossing boundaries are excluded. The 2026 test covers issue dates through 22 October for rainfall; temperature targets require available POWER observations and therefore end earlier at longer horizons. Explicit predictions contain exact dates and counts.

This is a retrospective observation-date benchmark, assuming day-t data are available at the end of day t. Actual NASA release latency is not represented. GPM changes from Final to Late Run in October 2025. Results are not validated operational forecast accuracy or farm-level weather accuracy.

## Files

- Notebook: full feature engineering, model fitting and outputs.
- benchmark.py: equivalent Python implementation.
- data/: eight original CSV copies (seven POWER regions, one combined GPM table).
- results/metrics.csv: validation and held-out test scores.
- results/test_predictions.csv: every test prediction and target, dates, location and GPM stream.
- results/subgroup_metrics.csv: region and month diagnostics.
- results/paired_block_intervals.csv: 14-day paired bootstrap intervals, conditional on fitted models.
- results/rain_calibration.csv: probability reliability bins.
- results/selected_configurations.csv: choices made using 2025 only.
- results/feature_schema.json and input_hashes.json: reproducibility.
- RESULTS.md: measured results and interpretation.
- NEW_DATASET_REVIEW.md: assessment of the subsequently supplied engineered panels.

No trained production model is exported. These experiments identify candidates for further availability-aware validation.
